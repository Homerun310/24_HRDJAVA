package com.example.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity5 extends AppCompatActivity {

    private TextView tvScrambledWord;
    private EditText etUserInput;
    private TextView tvResult;
    private String originalWord = "example"; // 맞춰야 할 원래 단어
    private String scrambledWord;
    private Button btnSubmit, showAnswerButton, backbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main5);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tvScrambledWord = findViewById(R.id.tvScrambledWord);
        etUserInput = findViewById(R.id.etUserInput);
        tvResult = findViewById(R.id.tvResult);
        btnSubmit = findViewById(R.id.btnSubmit);
        showAnswerButton = findViewById(R.id.showanswer);
        backbutton = findViewById(R.id.backfrommain5);

        // 단어를 섞어 보여줍니다.
        scrambledWord = shuffleWord(originalWord);
        tvScrambledWord.setText(scrambledWord);

        // 제출 버튼 클릭 이벤트 처리
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userGuess = etUserInput.getText().toString().trim();
                checkGuess(userGuess);
            }
        });

        showAnswerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 정답을 텍스트뷰에 표시
                tvScrambledWord.setText("정답: " + originalWord);
                tvScrambledWord.setVisibility(View.VISIBLE);
            }
        });

        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity5.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    // 단어를 섞는 메소드
    private String shuffleWord(String word) {
        List<Character> letters = new ArrayList<>();
        for (char c : word.toCharArray()) {
            letters.add(c);
        }
        Collections.shuffle(letters);
        StringBuilder shuffledWord = new StringBuilder();
        for (char c : letters) {
            shuffledWord.append(c);
        }
        return shuffledWord.toString();
    }

    // 사용자의 답변을 확인하는 메소드
    private void checkGuess(String guess) {
        if (guess.equalsIgnoreCase(originalWord)) {
            tvResult.setText("Correct! 정답은 " + originalWord);
        } else {
            tvResult.setText("Incorrect, try again.");
        }
    }


}