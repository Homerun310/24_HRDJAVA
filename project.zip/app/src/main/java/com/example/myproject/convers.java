package com.example.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class convers extends AppCompatActivity {
    private TextView categoryTextView;
    private TextView phraseTextView;
    private TextView translationTextView;
    private Button nextButton, backbutton;

    private int currentIndex = 0;

    private String[] categories = {
            "대중교통",
            "식당",
            "공항",
            "사무실",
            "학교",
            "병원"
    };

    private String[][] phrases = {
            {
                    "Where is the nearest bus stop?",
                    "How much is a ticket to downtown?",
                    "Can I use this metro card on buses?",
                    "Which line goes to the airport?",
                    "How often does the bus run?",
                    "Is this the right platform for the express train?",
                    "Do I need to transfer?",
                    "How long is the ride?",
                    "What time is the last train?",
                    "Where can I buy a ticket?"
            },
            {
                    "Could I see the menu, please?",
                    "Do you have any vegetarian options?",
                    "I’ll have the same as that table.",
                    "Could you make it less spicy?",
                    "Is service included in the bill?",
                    "Can I get this to go?",
                    "Could I get the check, please?",
                    "What do you recommend?",
                    "Is this dish gluten-free?",
                    "Do you have a kids' menu?"
            },
            {
                    "Where is the check-in counter?",
                    "Is my flight on time?",
                    "Where can I get a baggage cart?",
                    "Can I bring this as carry-on?",
                    "What time is boarding?",
                    "Where is the customs office?",
                    "Is there Wi-Fi available here?",
                    "Which way to the departure gate?",
                    "How long is the layover?",
                    "Can I upgrade my seat?"
            },
            {
                    "Could you please send the report by EOD?",
                    "Let’s schedule a meeting for next week.",
                    "Can I get your feedback on this?",
                    "How is the project progressing?",
                    "Do you need any assistance with that?",
                    "Could you forward me that email?",
                    "Let’s touch base later today.",
                    "What’s the status of our deliverables?",
                    "Please keep me in the loop.",
                    "Could you review this document?"
            },
            {
                    "Where is the library?",
                    "What time does the cafeteria open?",
                    "Can I borrow this book?",
                    "When is the assignment due?",
                    "Where can I print my documents?",
                    "Is there a student discount?",
                    "Can I change my course schedule?",
                    "Where is the nearest study room?",
                    "When are the final exams?",
                    "What is the Wi-Fi password?"
            },
            {
                    "Where is the emergency room?",
                    "How long is the wait time?",
                    "Do I need to make an appointment?",
                    "Is there a pharmacy nearby?",
                    "Can I see a specialist?",
                    "How much will the treatment cost?",
                    "Is this covered by insurance?",
                    "Can I get a copy of my medical records?",
                    "What are the visiting hours?",
                    "Is this prescription available here?"
            }
    };

    private String[][] translations = {
            {
                    "가장 가까운 버스 정류장은 어디인가요?",
                    "다운타운까지 가는 티켓은 얼마인가요?",
                    "이 지하철 카드를 버스에서도 사용할 수 있나요?",
                    "공항까지 가는 노선은 어디인가요?",
                    "버스는 얼마나 자주 운행되나요?",
                    "급행 열차가 이 플랫폼에서 출발하나요?",
                    "환승이 필요한가요?",
                    "소요 시간은 얼마나 되나요?",
                    "막차는 몇 시인가요?",
                    "티켓은 어디에서 구매할 수 있나요?"
            },
            {
                    "메뉴를 볼 수 있을까요?",
                    "채식주의자를 위한 메뉴가 있나요?",
                    "저도 저 테이블과 같은 것으로 할게요.",
                    "덜 맵게 해주실 수 있나요?",
                    "서비스 비용이 포함되어 있나요?",
                    "이걸 포장해주실 수 있나요?",
                    "계산서 부탁드립니다.",
                    "어떤 요리를 추천하시나요?",
                    "이 요리는 글루텐이 들어가지 않았나요?",
                    "어린이 메뉴가 있나요?"
            },
            {
                    "체크인 카운터는 어디인가요?",
                    "제 비행기가 제시간에 출발하나요?",
                    "짐 수레는 어디에서 구할 수 있나요?",
                    "이걸 기내 반입할 수 있나요?",
                    "탑승 시간은 언제인가요?",
                    "세관 사무소는 어디에 있나요?",
                    "여기 와이파이가 있나요?",
                    "출발 게이트는 어디로 가야 하나요?",
                    "경유 시간은 얼마나 되나요?",
                    "좌석을 업그레이드할 수 있나요?"
            },
            {
                    "오늘 업무 종료 전까지 보고서를 보내주실 수 있나요?",
                    "다음 주에 회의를 잡읍시다.",
                    "이것에 대해 피드백을 주시겠어요?",
                    "프로젝트 진행 상황은 어떤가요?",
                    "그것에 대해 도움이 필요하신가요?",
                    "그 이메일을 저에게 전달해 주시겠어요?",
                    "오늘 나중에 다시 논의합시다.",
                    "우리의 결과물 상태는 어떻습니까?",
                    "저를 계속 업데이트해 주세요.",
                    "이 문서를 검토해 주시겠어요?"
            },
            {
                    "도서관은 어디에 있나요?",
                    "식당은 몇 시에 열리나요?",
                    "이 책을 빌릴 수 있나요?",
                    "과제 제출 마감일은 언제인가요?",
                    "문서를 어디에서 인쇄할 수 있나요?",
                    "학생 할인이 있나요?",
                    "강의 일정을 변경할 수 있나요?",
                    "가장 가까운 스터디 룸은 어디인가요?",
                    "기말 시험은 언제인가요?",
                    "와이파이 비밀번호가 무엇인가요?"
            },
            {
                    "응급실은 어디에 있나요?",
                    "대기 시간이 얼마나 되나요?",
                    "예약을 해야 하나요?",
                    "근처에 약국이 있나요?",
                    "전문의와 상담할 수 있나요?",
                    "치료 비용이 얼마나 들까요?",
                    "이것은 보험으로 보장되나요?",
                    "제 의료 기록 사본을 받을 수 있나요?",
                    "면회 시간은 언제인가요?",
                    "이 처방전을 여기서 받을 수 있나요?"
            }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation);
        categoryTextView = findViewById(R.id.categoryTextView);
        phraseTextView = findViewById(R.id.phraseTextView);
        translationTextView = findViewById(R.id.translationTextView);
        nextButton = findViewById(R.id.nextButton);
        backbutton = findViewById(R.id.backfromconvers);

        updateText();

        nextButton.setOnClickListener(v -> {
            currentIndex++;
            if (currentIndex >= phrases.length * 10) {
                currentIndex = 0; // 처음으로 돌아가도록 설정
            }
            updateText();
        });

        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(convers.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void updateText() {
        int categoryIndex = currentIndex / 10; // 각 카테고리당 10개의 문장
        int phraseIndex = currentIndex % 10;

        categoryTextView.setText("장소: " + categories[categoryIndex]);
        phraseTextView.setText(phrases[categoryIndex][phraseIndex]);
        translationTextView.setText(translations[categoryIndex][phraseIndex]);
    }
}